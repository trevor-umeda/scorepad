package com.gamecounter;



import android.app.Application;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.util.Log;

public class GameCounterApplication extends Application {

	private GamesDbAdapter dbAdapter;
	private static final String TAG = GameCounterApplication.class.getSimpleName();

	public GamesDbAdapter getGamesDbAdapter(){
		if(dbAdapter==null){
			dbAdapter = new GamesDbAdapter(this);
		}
		return dbAdapter;
	}
	
	@Override
	public void onCreate() {
		super.onCreate();
		
		Log.i(TAG,"onCreated");
	}
	@Override
	public void onTerminate() {
		super.onTerminate();
		Log.i(TAG,"onTerminated");
	}
	public long createGame(String title, int startingPoints, int numOfPlayers,String amounts,int allowCustomValues) {
        ContentValues initialValues = new ContentValues();
        initialValues.put(GamesDbAdapter.C_TITLE, title);
        initialValues.put(GamesDbAdapter.C_STARTING_POINTS,startingPoints);
        initialValues.put(GamesDbAdapter.C_NUM_OF_PLAYERS,numOfPlayers);
        initialValues.put(GamesDbAdapter.C_AMOUNTS,amounts);
        initialValues.put(GamesDbAdapter.C_ALLOW_CUST_VALS,allowCustomValues);
        long returningId = this.getGamesDbAdapter().createGame(initialValues);
        Log.d(TAG,"Created game successfully. Game id is " + returningId);
        return returningId;
    }
	 public boolean deleteGame(long rowId) {

	        return this.getGamesDbAdapter().deleteGame(rowId);
	    }
	 public Cursor fetchAllGames() {

	        return this.getGamesDbAdapter().fetchAllGames();
	    }
	 public Cursor fetchGame(long rowId) throws SQLException {

	        Cursor cursor = this.getGamesDbAdapter().fetchGame(rowId);
	        return cursor;

	    }
	 public boolean updateGame(long rowId, String title, int startingPoints, int numOfPlayers,String amounts) {
	        ContentValues updatedValues = new ContentValues();
	        updatedValues.put(GamesDbAdapter.C_TITLE, title);
	        updatedValues.put(GamesDbAdapter.C_STARTING_POINTS,startingPoints);
	        updatedValues.put(GamesDbAdapter.C_NUM_OF_PLAYERS,numOfPlayers);
	        updatedValues.put(GamesDbAdapter.C_AMOUNTS,amounts);

	        return this.getGamesDbAdapter().updateGame(updatedValues,rowId);

	    }
}
