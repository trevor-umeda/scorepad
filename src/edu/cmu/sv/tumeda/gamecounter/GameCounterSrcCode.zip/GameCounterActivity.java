package com.gamecounter;


import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.InputType;
import android.text.method.DigitsKeyListener;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

public class GameCounterActivity extends Activity {
	/**
	 * @see android.app.Activity#onCreate(Bundle)
	 */
	static final int DIALOG_PAUSED_ID = 0;
	static final int DIALOG_COUNTER_ID = 1;
	
	String pointsName;
    private static final int ACTIVITY_POINTS=2;
	private LinearLayout layout;
	private LinearLayout layout2;
	
	private GameCounterApplication gameCounter;
	GamesDbAdapter dbAdapter;
    private static final String TAG = "GameCounterActivity";
    ArrayList<Boolean> incrementing;
    Boolean incrementCheck;
    ArrayList<Button> playerButtons;
    ArrayList<EditText> customAmounts;
    JSONArray items;
    int allowCustValues;
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
 		gameCounter = (GameCounterApplication) getApplication();
        setContentView(R.layout.gameview);
        layout = (LinearLayout) this.findViewById(R.id.gameviewmulti);
        incrementing = new ArrayList<Boolean>();
        playerButtons = new ArrayList<Button>();
        
        
        long gameId;
        if (savedInstanceState == null) {
         Bundle extras = getIntent().getExtras();
            if(extras == null) {
                gameId= (Long) null;
            } else {
            	
                gameId= extras.getLong(GamesDbAdapter.C_ID);
                
            }
        } else {
            Bundle extras = getIntent().getExtras();

            gameId= extras.getLong(GamesDbAdapter.C_ID);
        }
        Log.d(TAG,"Gameid is " + gameId);

        
        Cursor cursor = gameCounter.fetchGame(gameId);
        startManagingCursor(cursor);
        
        pointsName = cursor.getString(cursor.getColumnIndexOrThrow(GamesDbAdapter.C_POINTS_NAME));
        TextView text1 = new TextView(this);

        text1.setText("Game Name: " + cursor.getString(
                cursor.getColumnIndexOrThrow(GamesDbAdapter.C_TITLE)));
        layout.addView(text1);
       
        TextView text2 = new TextView(this);
        int numOfPlayers = cursor.getInt(cursor.getColumnIndexOrThrow(GamesDbAdapter.C_NUM_OF_PLAYERS));
        Log.d(TAG,""+numOfPlayers);
        text2.setText("Number of Players " + numOfPlayers);
        layout.addView(text2);
        
        String amounts = cursor.getString(cursor.getColumnIndexOrThrow(GamesDbAdapter.C_AMOUNTS));
		Log.d(TAG,"cursor index for amounts is " + cursor.getColumnIndexOrThrow(GamesDbAdapter.C_AMOUNTS));
		JSONObject json;
		items = null;
		
		try {
			json = new JSONObject(amounts);
			items = json.optJSONArray("uniqueArrays");

		} catch (JSONException e) {
			e.printStackTrace();
		}
		allowCustValues = cursor.getInt(cursor.getColumnIndexOrThrow(GamesDbAdapter.C_ALLOW_CUST_VALS));

        if(numOfPlayers > 2){
        	customAmounts = new ArrayList<EditText>();

        	for(int j = 0; j< numOfPlayers; j++){
        		final int currentPlayerNum = j;
				final Button playerButton = new Button(this);
        		int starting_points = cursor.getInt(cursor.getColumnIndexOrThrow(GamesDbAdapter.C_STARTING_POINTS));
				playerButton.setText("Player "+ (currentPlayerNum + 1) +": " + starting_points);
				
        		
        		final String finalItems = amounts;
        		
				playerButton.setOnClickListener(new View.OnClickListener() {

					public void onClick(View view) {
	
				        Intent i = new Intent(view.getContext(), GameIncrementerActivity.class);
				        i.putExtra("amounts", finalItems);
				        i.putExtra("playerNumber", currentPlayerNum);
				        //startActivityForResult(i, ACTIVITY_POINTS);
				     // custom dialog
						final Dialog dialog = new Dialog(view.getContext());
						dialog.setContentView(R.layout.incrementdialog);
						dialog.setTitle("Player "+ currentPlayerNum + " Score Changer");
				    	 layout2 = (LinearLayout) dialog.findViewById(R.id.incrementDialog);
				         
				    	 final TextView dialogDescription = new TextView(view.getContext());
				    	 dialogDescription.setText("Click the amount to increment by");
				    	 layout2.addView(dialogDescription);
				    	 ToggleButton incrementToggle = new ToggleButton(view.getContext());
				         
				    	 incrementToggle.setTextOn("Increment");
				 		incrementToggle.setTextOff("Decrement");
				 		incrementToggle.setChecked(true);
				 		incrementCheck = true;
				 		incrementToggle.setOnClickListener(new OnClickListener(){

				 			@Override
				 			public void onClick(View v) {
				 				 // Perform action on clicks
				 		        if (((ToggleButton) v).isChecked()) {
				 		        	incrementCheck = true;
							    	 dialogDescription.setText("Click the amount to increment by");

				 		        } else {
				 		        	Log.d("GameCounterActivity","incrementing should be false now");
				 		        	incrementCheck = false;
							    	 dialogDescription.setText("Click the amount to decrement by");

				 		        }						
				 			}
				 			
				 		});
				 		layout2.addView(incrementToggle);

				 		
		        		if(items != null){
		        			for(int k = 0; k < items.length(); k ++){
		        				try {
		        					final String item = (String) items.get(k);
		        					Button amountButton = new Button(view.getContext());
		        					amountButton.setText(item);
		        					amountButton.setWidth(50);
		        					amountButton.setOnClickListener(new View.OnClickListener() {

		        						public void onClick(View view) {
		        							String test = (String) playerButton.getText();
		        			        		String[] splitPoints = test.split(": ");
		        			        		if(incrementCheck){
		        			        			playerButton.setText("Player "+ (currentPlayerNum + 1) +": " + (Integer.parseInt(splitPoints[1]) + Integer.parseInt(item)));
		        								dialog.dismiss();

		        			        		}else{
		        			        		playerButton.setText("Player "+ (currentPlayerNum + 1) +": " + (Integer.parseInt(splitPoints[1]) - Integer.parseInt(item)));
		    								dialog.dismiss();

		        			        		}
		        			        	}

		        					});
		        					layout2.addView(amountButton);
		        				} catch (JSONException e) {
		        					// TODO Auto-generated catch block
		        					e.printStackTrace();
		        				}
		        			}
		        		}
		                if(allowCustValues == 1){
		                	
		                	final EditText custAmount  = new EditText(view.getContext());
		                	
		                	custAmount.setInputType(InputType.TYPE_CLASS_PHONE);
		                	custAmount.setKeyListener(DigitsKeyListener.getInstance("0123456789."));
		                	customAmounts.add(custAmount);
		                	Button custAmountButton = new Button(view.getContext());
		                	custAmountButton.setText("Input");
		                	
		                	
		                	layout2.addView(custAmount);
		                	layout2.addView(custAmountButton);
		            		

		            		

		                	custAmountButton.setOnClickListener(new OnClickListener(){
		                		@Override
		                		public void onClick(View v) {
		                			// TODO Auto-generated method stub
		                			final String modifiedPoints =  custAmount.getText().toString();

		                			String test = (String) playerButton.getText();
        			        		String[] splitPoints = test.split(": ");
        			        		if(incrementCheck){
        			        			playerButton.setText("Player "+ (currentPlayerNum + 1) +": " + (Integer.parseInt(splitPoints[1]) + Integer.parseInt(modifiedPoints)));
        								dialog.dismiss();

        			        		}else{
        			        		playerButton.setText("Player "+ (currentPlayerNum + 1) +": " + (Integer.parseInt(splitPoints[1]) - Integer.parseInt(modifiedPoints)));
    								dialog.dismiss();

        			        		}

		                		}
		                		
		                	});
		                }
						dialog.show();		        	}

				});
				layout.addView(playerButton);
				playerButtons.add(playerButton);

        	}
        }
        else{
        	customAmounts = new ArrayList<EditText>();
        	
        	for(int j = 0; j < numOfPlayers ; j++){
        		LinearLayout playerInfoLayout = (LinearLayout)findViewById(R.id.player_info);
        		 
                // Create new LayoutInflater - this has to be done this way, as you can't directly inflate an XML without creating an inflater object first
                LayoutInflater inflater = getLayoutInflater();
                View playersInfoView = inflater.inflate(R.layout.player_info, null);
                LinearLayout buttonsLayout = (LinearLayout) playersInfoView.findViewById(R.id.amountsList);
               // playerInfoLayout.addView(playersInfo);
                
        		final int currentPlayerNum = j;
        		final TextView playerPoints = new TextView(this);
        		int starting_points = cursor.getInt(cursor.getColumnIndexOrThrow(GamesDbAdapter.C_STARTING_POINTS));
        		Log.d(TAG,""+starting_points);
        		playerPoints.setText("Player "+ (currentPlayerNum + 1) + ":"+ starting_points );
        		playerPoints.setTextSize(20);
        		 playerInfoLayout.addView(playerPoints);
        		
        		ToggleButton incrementToggle = new ToggleButton(this);
        		
        		incrementToggle.setTextOn("Increment");
        		incrementToggle.setTextOff("Decrement");
        		incrementToggle.setChecked(true);
        		incrementing.add(true);
        		incrementToggle.setOnClickListener(new OnClickListener(){

					@Override
					public void onClick(View v) {
						 // Perform action on clicks
				        if (((ToggleButton) v).isChecked()) {
				        	incrementing.set(currentPlayerNum, true);
				        } else {
				        	incrementing.set(currentPlayerNum, false);
				        }						
					}
        			
        		});
        		 playerInfoLayout.addView(incrementToggle);
        		
        		Log.d(TAG,"cursor index for amounts is " + cursor.getColumnIndexOrThrow(GamesDbAdapter.C_AMOUNTS));
        		
        		 items = null;
        		
        		try {
        			json = new JSONObject(amounts);
        			items = json.optJSONArray("uniqueArrays");

        		} catch (JSONException e) {
        			e.printStackTrace();
        		}
        		if(items != null){
        			for(int i = 0; i < items.length(); i ++){
        				try {
        					final String item = (String) items.get(i);
        					Button amountButton = new Button(this);
        					amountButton.setText(item);
        					amountButton.setWidth(200);
        					amountButton.setOnClickListener(new View.OnClickListener() {

        						public void onClick(View view) {
        							String test = (String) playerPoints.getText();
        			        		String[] splitPoints = test.split(":");
        			        		if(incrementing.get(currentPlayerNum)){
        			        			playerPoints.setText("Player "+ (currentPlayerNum + 1)+ ":"+  (Integer.parseInt(splitPoints[1]) + Integer.parseInt(item)));
        			        		}else{
        			        		playerPoints.setText("Player "+ (currentPlayerNum + 1) + ":"+  (Integer.parseInt(splitPoints[1]) - Integer.parseInt(item)));
        			        		}
        			        	}

        					});
        					buttonsLayout.addView(amountButton);
        				} catch (JSONException e) {
        					// TODO Auto-generated catch block
        					e.printStackTrace();
        				}
        				
        			}
        			

        		}
                if(allowCustValues == 1){
                	
                	EditText custAmount  = new EditText(this);
                	
                	custAmount.setInputType(InputType.TYPE_CLASS_PHONE);
                	custAmount.setKeyListener(DigitsKeyListener.getInstance("0123456789."));
                	customAmounts.add(custAmount);
                	Button custAmountButton = new Button(this);
                	custAmountButton.setText("Input");
                	
                	
                	buttonsLayout.addView(custAmount);
                	buttonsLayout.addView(custAmountButton);
            		



                	custAmountButton.setOnClickListener(new OnClickListener(){
                		@Override
                		public void onClick(View v) {
                			// TODO Auto-generated method stub
                			final String modifiedPoints = customAmounts.get(currentPlayerNum).getText().toString();
                			Log.d(TAG,"modified Points is " + modifiedPoints);
                			String test = (String) playerPoints.getText();
    		        		String[] splitPoints = test.split(":");
    		        		if(incrementing.get(currentPlayerNum)){
			        			playerPoints.setText("Player "+ (currentPlayerNum + 1)+ ":" + (Integer.parseInt(splitPoints[1]) + Integer.parseInt(modifiedPoints)));
			        		}else{
			        		playerPoints.setText("Player "+ (currentPlayerNum + 1)+ ":" + (Integer.parseInt(splitPoints[1]) - Integer.parseInt(modifiedPoints)));
			        		}

                		}
                		
                	});
                }
				playerInfoLayout.addView(playersInfoView);

        	}
          
		}

        cursor.close();

    }
	protected Dialog onCreateDialog(int id) {
		Context mContext = getApplicationContext();
		Dialog dialog = new Dialog(mContext);
	    switch(id) {
	    case DIALOG_PAUSED_ID:
	        // do the work to define the pause Dialog
	        break;
	    case DIALOG_COUNTER_ID:
	    	dialog.setContentView(R.layout.gameview);
	    	layout = (LinearLayout) this.findViewById(R.id.gameview);
	    	ToggleButton incrementToggle = new ToggleButton(this);
			
			incrementToggle.setTextOn("Increment");
			incrementToggle.setTextOff("Decrement");
			incrementToggle.setChecked(true);
			 incrementCheck = true;
			incrementToggle.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View v) {
					 // Perform action on clicks
			        if (((ToggleButton) v).isChecked()) {
			        	incrementCheck = true;
			        } else {
			        	Log.d("GameCounterActivity","incrementing should be false now");
			        	incrementCheck = false;
			        }						
				}
				
			});
			layout.addView(incrementToggle);

	    	break;
	    default:
	        dialog = null;
	    }
	    return dialog;
	}
	@Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.d("CheckStartActivity","onActivityResult and resultCode = "+resultCode);
        // TODO Auto-generated method stub
        super.onActivityResult(requestCode, resultCode, data);
        Bundle extras = data.getExtras();
		String returnAmount = extras.getString("returnAmount");
		final int playerNum = extras.getInt("playerNumber");
		Button playerButton = playerButtons.get(playerNum);
		
		Log.d(TAG,"adding " + Integer.parseInt(returnAmount));
        if(resultCode==ACTIVITY_POINTS){
        	String buttonText = (String) playerButton.getText();
    		String[] splitPoints = buttonText.split(": ");
   			playerButton.setText("Player "+ playerNum +": " + (Integer.parseInt(splitPoints[1]) + Integer.parseInt(returnAmount)));
        }
        else{
        }
    }
	

}
