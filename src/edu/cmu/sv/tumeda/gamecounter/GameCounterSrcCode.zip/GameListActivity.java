package com.gamecounter;



import android.app.ListActivity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ContextMenu.ContextMenuInfo;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.AdapterView.AdapterContextMenuInfo;

public class GameListActivity extends ListActivity {
	private static final int ACTIVITY_CREATE=0;
    private static final int ACTIVITY_EDIT=1;
	private GameCounterApplication gameCounter;
	GamesDbAdapter dbAdapter;
	Cursor cursor;
	ListView listGames;
    private static final String TAG = "GameListActivity";
	private static final int DELETE_ID = 2;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
       
    	super.onCreate(savedInstanceState);
        setContentView(R.layout.gamelist);   
        gameCounter = (GameCounterApplication) getApplication();		
        
        fillData();
        registerForContextMenu(getListView());

    }
    private void fillData() {
        Cursor gamesCursor = gameCounter.fetchAllGames();
        startManagingCursor(gamesCursor);

        // Create an array to specify the fields we want to display in the list (only TITLE)
        String[] from = new String[]{GamesDbAdapter.C_TITLE};

        // and an array of the fields we want to bind those fields to (in this case just text1)
        int[] to = new int[]{R.id.game_row};

        // Now create a simple cursor adapter and set it to display
        SimpleCursorAdapter games = 
            new SimpleCursorAdapter(this, R.layout.gamesrow, gamesCursor, from, to);
        setListAdapter(games);
    }
    
    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
        Log.d(TAG,"row id of: " + id);
        Cursor cursor = ((Cursor) l.getItemAtPosition(position));
        Log.d(TAG,"Something else " +  cursor.getString(cursor.getColumnIndexOrThrow(GamesDbAdapter.C_ID)));
        Intent i = new Intent(this, GameCounterActivity.class);
        i.putExtra(GamesDbAdapter.C_ID, id);
        startActivityForResult(i, ACTIVITY_EDIT);

    }
    
    
    /*
     * Menu stuff
     */
    // Called first time user clicks on the menu button
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
    	MenuInflater inflater = getMenuInflater();
    	inflater.inflate(R.menu.menu, menu);
    	return true;
    }
    
    
    //Called when an options item is clicked
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
    	switch(item.getItemId()){
    	case R.id.newGameRules:
    		 Intent i = new Intent(this, NewGameActivity.class);
    	     startActivityForResult(i, ACTIVITY_CREATE);    		
    	     break;
    	}
    	
    	return true;
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        fillData();
    }
    
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
            ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.add(0, DELETE_ID, 0, R.string.menu_delete);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case DELETE_ID:
                AdapterContextMenuInfo info = (AdapterContextMenuInfo) item.getMenuInfo();
                gameCounter.deleteGame(info.id);
                fillData();
                return true;
        }
        return super.onContextItemSelected(item);
    }
    
}