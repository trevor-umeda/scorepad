package com.gamecounter;


import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;


public class NewGameActivity extends Activity {
    private static final String TAG = "NewGameActivity";

	private EditText mTitleText;
    private EditText mStartingAmountText;
    private Spinner spinner;
    private ArrayList<EditText> amountList;
    private Long mRowId;
    private GamesDbAdapter mDbHelper;
    private int incrementingId;
    private GameCounterApplication gameCounter;
    private int allowCustomValues;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		 super.onCreate(savedInstanceState);
		 gameCounter = (GameCounterApplication)getApplication();

	        setContentView(R.layout.newgames);
	        setTitle(R.string.titleNewGame);

	        mTitleText = (EditText) findViewById(R.id.title);
	        mStartingAmountText = (EditText) findViewById(R.id.starting_points);
	        
	        
	        spinner = (Spinner) findViewById(R.id.spinner);
	        
	        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
	                this, R.array.numbers_array, android.R.layout.simple_spinner_item);
	        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	        spinner.setAdapter(adapter);
	       // spinner.setOnItemSelectedListener(new MyOnItemSelectedListener());
	        
	        amountList = new ArrayList<EditText>();
	        
	        Button confirmButton = (Button) findViewById(R.id.confirm);

	        confirmButton.setOnClickListener(new View.OnClickListener() {

	            public void onClick(View view) {
	                setResult(RESULT_OK);
	                finish();
	            }

	        });
	        
	        allowCustomValues = 0;
	        
	     // Watch for button clicks.
	        Button button = (Button)findViewById(R.id.add_box);
	        button.setOnClickListener(addBoxListener);
	        
	        
	        final EditText edittext = (EditText) findViewById(R.id.txt_submit_name);
	        
	        edittext.setOnKeyListener(new OnKeyListener() {
	            public boolean onKey(View v, int keyCode, KeyEvent event) {
	                // If the event is a key-down event on the "enter" button
	                if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
	                    (keyCode == KeyEvent.KEYCODE_ENTER)) {
	                  // Perform action on key press
	                  Toast.makeText(NewGameActivity.this, edittext.getText(), Toast.LENGTH_SHORT).show();
	                  return true;
	                }
	                return false;
	            }

				
	        });
	        amountList.add(edittext);
	        incrementingId = 1;
	}
	private OnClickListener addBoxListener = new OnClickListener(){
		public void onClick(View v){
			// Get a reference to the score_name_entry object in score.xml
            LinearLayout submitScoreLayout = (LinearLayout)findViewById(R.id.additional_value);
            
 
            // Create new LayoutInflater - this has to be done this way, as you can't directly inflate an XML without creating an inflater object first
            LayoutInflater inflater = getLayoutInflater();
            View additionalView = inflater.inflate(R.layout.additional_value, null);
            EditText newEdit = (EditText) additionalView.findViewById(R.id.txt_submit_name);
            //EditText newEdit = (EditText) findViewById(R.layout.additional_value);
            newEdit.setId(R.id.txt_submit_name + incrementingId);
            incrementingId++;
            submitScoreLayout.addView(additionalView);
            
            final EditText finalEdit = newEdit;
            finalEdit.setOnKeyListener(new OnKeyListener() {
	            public boolean onKey(View v, int keyCode, KeyEvent event) {
	                // If the event is a key-down event on the "enter" button
	                if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
	                    (keyCode == KeyEvent.KEYCODE_ENTER)) {
	                  // Perform action on key press
	                  Toast.makeText(NewGameActivity.this, finalEdit.getText(), Toast.LENGTH_SHORT).show();
	                  return true;
	                }
	                return false;
	            }

				
	        });
            amountList.add(finalEdit);
         
		}
	};
	public void onCheckboxClicked(View v) {
        // Perform action on clicks, depending on whether it's now checked
		LinearLayout submitScoreLayout = (LinearLayout)findViewById(R.id.additional_value);
        
//       
		 if (((CheckBox) v).isChecked()) {
			 submitScoreLayout.removeAllViews();
			 Log.d(TAG,"removing stuff");
			 amountList.removeAll(amountList);
			 allowCustomValues = 1;
		 } else {
			 Log.d(TAG,"Adding back the additional boxes");
			 // Create new LayoutInflater - this has to be done this way, as you can't directly inflate an XML without creating an inflater object first
	        LayoutInflater inflater = getLayoutInflater();
	        View additionalView = inflater.inflate(R.layout.additional_value, null);
	        EditText newEdit = (EditText) additionalView.findViewById(R.id.txt_submit_name);
	        //EditText newEdit = (EditText) findViewById(R.layout.additional_value);
	        newEdit.setId(R.id.txt_submit_name + incrementingId);
	        incrementingId++;
	        submitScoreLayout.addView(additionalView);
            final EditText finalEdit = newEdit;

            amountList.add(finalEdit);
            allowCustomValues = 0;

	        }
    }
	@Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        saveState();
        outState.putSerializable(GamesDbAdapter.C_ID, mRowId);
    }

	@Override
    protected void onPause() {
        super.onPause();
        if(!(mTitleText.getText().toString().matches("")) || !(mStartingAmountText.getText().toString().matches("")));
        {
        	if(mTitleText.getText().toString().matches(""))
        	{Log.d(TAG,"titltext is " +mTitleText.getText().toString());}
        	else saveState();
        }
    }
	private void saveState() {
        String title = mTitleText.getText().toString();
        int startingAmount = Integer.parseInt(mStartingAmountText.getText().toString());
        int totalPlayers = Integer.parseInt(spinner.getSelectedItem().toString());
         
        ArrayList<String> items = new ArrayList<String>();
        for(EditText amount : amountList){
        	items.add(amount.getText().toString());
        }
        
        JSONObject json = new JSONObject(); 
        try {
			json.put("uniqueArrays", new JSONArray(items));
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
        String amounts = json.toString();
        
        
        //if (mRowId == null) {
        	Log.d(TAG,"not worrying about mrowId at the moment");
            long id = gameCounter.createGame(title, startingAmount,totalPlayers,amounts,allowCustomValues);
            if (id > 0) {
                mRowId = id;
                Log.d(TAG,"succesfully,id is " + id);
            }
        //} 
//        else {
//        	gameCounter.updateGame(mRowId, title, startingAmount,totalPlayers,amounts);
//        }
    }
    
//    public class MyOnItemSelectedListener implements OnItemSelectedListener {
//
//        public void onItemSelected(AdapterView<?> parent,
//            View view, int pos, long id) {
//          Toast.makeText(parent.getContext(), "The planet is " +
//              parent.getItemAtPosition(pos).toString(), Toast.LENGTH_LONG).show();
//        }
//
//        public void onNothingSelected(AdapterView parent) {
//          // Do nothing.
//        }
//    }
}
